def suggest_viral_tags(tags):

    viral_tags = ['socialhub', 'trending', 'viral', 'popular']
    
    return viral_tags
